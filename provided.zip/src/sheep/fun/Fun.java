package sheep.fun;

import sheep.core.SheetUpdate;

public interface Fun {
    void draw(SheetUpdate sheet) throws FunException;
}
