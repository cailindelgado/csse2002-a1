/**
 * <span style="color: #f8981d"><i>(provided)</i></span>
 * An implementation of a graphical user interface in Swing.
 */
package sheep.ui.graphical;