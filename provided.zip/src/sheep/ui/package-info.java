/**
 * <span style="color: #f8981d"><i>(provided)</i></span>
 * User interfaces.
 */
package sheep.ui;