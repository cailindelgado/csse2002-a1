/**
 *  <span style="color: #f8981d"><i>(provided)</i></span>
 *  An implementation of a textual user interface.
 */
package sheep.ui.textual;