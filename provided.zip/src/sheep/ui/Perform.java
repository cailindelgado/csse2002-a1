package sheep.ui;

public interface Perform {
    void perform(int row, int column, Prompt prompt);
}
