/**
 * <span style="color: #f8981d"><i>(provided)</i></span>
 * The core interface between a spreadsheet and a user interface.
 */
package sheep.core;