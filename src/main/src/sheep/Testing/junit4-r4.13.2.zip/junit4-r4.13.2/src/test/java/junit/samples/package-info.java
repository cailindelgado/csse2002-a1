/**
 * JUnit v3.x examples.
 */
package junit.samples;